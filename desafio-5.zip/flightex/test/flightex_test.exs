defmodule FlightexTest do
  use ExUnit.Case
  doctest Flightex

  test "greets the world" do
    assert Flightex.hello() == :world
  end
end
