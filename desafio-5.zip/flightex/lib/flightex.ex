defmodule Flightex do
  alias Flightex.Booking.Agent, as: BookingAgent
end
