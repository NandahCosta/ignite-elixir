defmodule Flightex.Bookings.Agent do
  use Agent

  alias Flightex.Bookings.Booking

  def start_link(_params) do
    Agent.start_link(fn -> %{} end, name: __MODULE__)
  end
end
