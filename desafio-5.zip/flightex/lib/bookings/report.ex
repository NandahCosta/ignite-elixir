defmodule Flightex.Bookings.Report do
  alias Flightex.Bookings.Agent, as: BookingAgent
  alias Flightex.Bookings.{Booking, Validation}

  defp builf_csv(content) when length(content) > 0 do
    case File.write("reports/flight_booking_report.csv", content) do
      {:error, _reason} -> {:error, "Report faild"}
      _ -> {:ok, "Successfully"}
    end
  end

  defp build_csv(_content), do: {:error, "There is no data"}
end
