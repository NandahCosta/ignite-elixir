defmodule Flightex.Bookings.Booking do
  @keys [:id, :date, :ori_city, :des_city, :id_user]
  @enforce_keys @keys
  defstruct @keys

  def build(%{}) do
    %__MODULE__{
      id: UUID.uuid4(),
      date: date,
      ori_city: ori_city,
      des_city: des_city,
      id_user: id_user
    }
  end
end
