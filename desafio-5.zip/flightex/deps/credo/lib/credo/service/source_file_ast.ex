defmodule Credo.Service.SourceFileAST do
  @moduledoc false

  use Credo.Service.ETSTableHelper
end
