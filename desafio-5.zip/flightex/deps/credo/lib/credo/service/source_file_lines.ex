defmodule Credo.Service.SourceFileLines do
  @moduledoc false

  use Credo.Service.ETSTableHelper
end
